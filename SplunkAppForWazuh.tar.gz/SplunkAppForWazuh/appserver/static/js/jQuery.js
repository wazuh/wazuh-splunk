define(
   ['localjQuery'],
 
   function($) {
       return $.noConflict(true);
   }
);