define([
  './main/settingsCtrl',
  './index/settingsIndexCtrl',
  './api/settingsApiCtrl',
  './logs/logsCtrl',
  './about/aboutCtrl',
  './configuration/settingsConfigCtrl'
], function() {})
